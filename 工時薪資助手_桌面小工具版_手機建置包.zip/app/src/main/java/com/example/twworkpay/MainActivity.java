package com.example.twworkpay;

import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import java.text.*;import java.util.*;import org.json.*;

public class MainActivity extends Activity {
 WebView web; android.content.SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("work",0); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.addJavascriptInterface(new Bridge(this),"Android"); web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String u){String d=prefs.getString("db",""); if(!d.isEmpty()) v.evaluateJavascript("window.__applyCloudData("+JSONObject.quote(d)+")",null);}}); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
 public class Bridge { Context c; Bridge(Context c){this.c=c;} @JavascriptInterface public void syncData(String json){prefs.edit().putString("db",json).apply(); TodayWidgetProvider.updateAll(c);} @JavascriptInterface public String email(){return "";} @JavascriptInterface public void logout(){} }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
